package com.example.fastfoodordering

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
